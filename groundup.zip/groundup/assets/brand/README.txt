Ground Up, Inc. Landscaping — Brand Asset Pack (raster)

Files:
- groundup-wordmark_transparent.png (recommended for web headers)
- groundup-wordmark_blackbg.png (use on dark backgrounds)
- *_WIDTH.png variants for performance
- groundup-tree_transparent.png + size variants (icon / favicon base)

Notes:
- Transparent versions remove near-black background pixels from the original.
- If you see a faint edge on certain backgrounds, use the blackbg version instead.
